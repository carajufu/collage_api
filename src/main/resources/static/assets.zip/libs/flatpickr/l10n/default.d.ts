import { Locale } from "../types/locale";
export declare const english: Locale;
export default english;
