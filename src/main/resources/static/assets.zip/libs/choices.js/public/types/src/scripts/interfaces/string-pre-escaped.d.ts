export interface StringPreEscaped {
    readonly trusted: string;
}
