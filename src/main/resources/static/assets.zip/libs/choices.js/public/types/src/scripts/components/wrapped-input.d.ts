import WrappedElement from './wrapped-element';
export default class WrappedInput extends WrappedElement<HTMLInputElement> {
}
