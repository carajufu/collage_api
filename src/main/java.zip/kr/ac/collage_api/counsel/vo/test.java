package kr.ac.collage_api.counsel.vo;

public class test {
}
