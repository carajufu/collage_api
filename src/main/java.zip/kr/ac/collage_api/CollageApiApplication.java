package kr.ac.collage_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollageApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(CollageApiApplication.class, args);
    }

}
