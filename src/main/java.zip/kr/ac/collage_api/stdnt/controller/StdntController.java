package kr.ac.collage_api.stdnt.controller;


public class StdntController {
    
}
