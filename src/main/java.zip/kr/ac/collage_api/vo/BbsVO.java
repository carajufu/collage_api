package kr.ac.collage_api.vo;

import lombok.Data;

@Data
public class BbsVO {

	private String estbllctreCode;
	private String bbsNm;
	private String bbsDc;
	private int bbsCode;

}
