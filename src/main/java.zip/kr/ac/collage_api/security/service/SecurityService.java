package kr.ac.collage_api.security.service;

public interface SecurityService {

}
