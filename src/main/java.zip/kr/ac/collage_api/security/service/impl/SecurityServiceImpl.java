package kr.ac.collage_api.security.service.impl;

import kr.ac.collage_api.security.service.SecurityService;

public class SecurityServiceImpl implements SecurityService {

}
