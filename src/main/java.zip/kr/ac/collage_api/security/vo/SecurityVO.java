package kr.ac.collage_api.security.vo;

public class SecurityVO {

}
