package kr.ac.collage_api.security.controller;

public class SecurityController {

}
