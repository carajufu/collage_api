package kr.ac.collage_api.learning.vo;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class QuizExVO {
    private String quizExCode;
    private String quizCode;
    private String exNo;
    private String exCn;
    private String cnslAt;
}
