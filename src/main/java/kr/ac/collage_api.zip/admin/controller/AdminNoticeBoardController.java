package kr.ac.collage_api.admin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import kr.ac.collage_api.admin.service.BbsNoticeService;
import kr.ac.collage_api.vo.BbsVO;
import lombok.extern.slf4j.Slf4j;

@CrossOrigin(origins = "*" )
@RequestMapping("/admin/bbs")
@Slf4j
@RestController
public class AdminNoticeBoardController {

	@Autowired
	BbsNoticeService bbsNoticeService;
	
	@GetMapping("/getlist")
	public Map<String,Object> getlist () {
		
		List<BbsVO> bbsVOList = this.bbsNoticeService.adminList();
		log.info("adminList() -> bbsVOList : {}", bbsVOList);
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("bbsVOList",bbsVOList);
		return map;
	}
	

	
	@PutMapping("/putdetail")
	public int putdetail(@RequestBody BbsVO bbsVO) {
		log.info("putdetail() -> bbsVO : {}", bbsVO);
		int result = this.bbsNoticeService.adminPutDetail(bbsVO);
		
		return result;
	}
	
	/*
	 export const deleteNoticeBoard = (id) => {
     return API.delete(`/admin/bbs/deletedetail/${id}`)
}
	 
	*/
	
	@DeleteMapping("/deletedetail/{bbscttNo}")
	public int deletedetail(@PathVariable int bbscttNo) {
		
		int result = this.bbsNoticeService.adminDeleteDetail(bbscttNo);
		
		return result;
	}
	
	/*export const postNoticeBoard = () => {
    return API.post("/admin/bbs/postdetail")
	}
	 */
	
	@PostMapping("/postdetail")
	public int postdetail(@RequestBody BbsVO bbsVO) {
		String acntId = "a001";
		
		//만약 jwt 토큰을 저장해서 보내왓고, 그걸 pincipal로 Userdetais 객체를 저장했다면
		//if 문 써야 하는데 이건 종우씨한테 물어보기 ㄱㄱ
		
		bbsVO.setAcntId(acntId);
		
		
		log.info("postdetail() -> bbsVO : {}", bbsVO);
		int result = this.bbsNoticeService.adminPostDetail(bbsVO);
		return result;
		
	}
	
	
	
}
