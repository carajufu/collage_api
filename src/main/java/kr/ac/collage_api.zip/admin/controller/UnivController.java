package kr.ac.collage_api.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import kr.ac.collage_api.admin.service.UnivService;
import kr.ac.collage_api.vo.UnivVO;

@RestController
@RequestMapping("/admin/univ")
public class UnivController {
	
	@Autowired
	private UnivService univService;
	
	//목록
	@GetMapping("/tree")
	public List<UnivVO> getUnivTree(){
		return univService.getUnivTreeList();
	}
}
