package kr.ac.collage_api.admin.service.impl;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.collage_api.admin.mapper.UnivMapper;
import kr.ac.collage_api.admin.service.UnivService;
import kr.ac.collage_api.vo.SubjctVO;
import kr.ac.collage_api.vo.UnivVO;

@Service
public class UnivServiceImpl implements  UnivService{

	@Autowired
	private UnivMapper univMapper;
	
	//목록
	@Override
	public List<UnivVO> getUnivTreeList() {
		
		List<UnivVO> univList = univMapper.findAllUniv();
		List<SubjctVO> subjctList = univMapper.findAllSubjct();
		
		//그룹핑
		Map<String, List<SubjctVO>> subjctsByUnivCode = 
				subjctList.stream().collect(Collectors.groupingBy((subjct) -> subjct.getUnivCode()));
		//단과대에 학과 넣기
		univList.forEach(univ ->{
			List<SubjctVO> children = subjctsByUnivCode.get(univ.getUnivCode());
			
			if(children != null) {univ.setChildren(children);}
		});
				
		return univList;
	}

}
