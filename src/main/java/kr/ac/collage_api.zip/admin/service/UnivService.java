package kr.ac.collage_api.admin.service;

import java.util.List;

import org.springframework.stereotype.Service;

import kr.ac.collage_api.vo.UnivVO;

@Service
public interface UnivService {

	//목록
	List<UnivVO> getUnivTreeList();

}
