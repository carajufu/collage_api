package kr.ac.collage_api.grade.mapper;

public class test {
}
