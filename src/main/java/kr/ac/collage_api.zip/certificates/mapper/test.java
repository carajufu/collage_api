package kr.ac.collage_api.certificates.mapper;

public class test {
}
