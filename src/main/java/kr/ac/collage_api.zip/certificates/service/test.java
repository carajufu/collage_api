package kr.ac.collage_api.certificates.service;

public class test {
}
