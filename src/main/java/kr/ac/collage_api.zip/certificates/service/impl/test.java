package kr.ac.collage_api.certificates.service.impl;

public class test {
}
