package kr.ac.collage_api.account.service;

public interface AccountService {

}
