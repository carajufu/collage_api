package kr.ac.collage_api.dashboard.vo;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DashLectureVO {
    private String lctreNm;
    private String lctrum;
    private String estbllctreCode;
    private String sklstfNm;
}
